export interface IPrivateSession {
    cookie: string;
}