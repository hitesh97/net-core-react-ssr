﻿export interface ILoginModel {
    login: string;
    password: string;
    rememberMe?: boolean;
}