﻿export interface IServiceUser {
    login: string;
}