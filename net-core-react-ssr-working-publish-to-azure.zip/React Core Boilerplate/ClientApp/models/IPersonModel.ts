export interface IPersonModel {
    id?: number;
    firstName?: string;
    lastName?: string;
}