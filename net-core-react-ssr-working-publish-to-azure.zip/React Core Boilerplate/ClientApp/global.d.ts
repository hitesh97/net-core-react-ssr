/// <reference path="../node_modules/ts-nameof/ts-nameof.d.ts" />
declare module '*.png';
declare module '*.jpg';
declare module '*.jpeg';
declare module '*.gif';
declare module '*.svg';