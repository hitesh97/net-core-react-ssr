﻿namespace React_Core_Boilerplate
{
    public static class Constants
    {
        public static string AuthorizationCookieKey => "Auth";
        public static string HttpContextServiceUserItemKey => "ServiceUser";
    }
}
