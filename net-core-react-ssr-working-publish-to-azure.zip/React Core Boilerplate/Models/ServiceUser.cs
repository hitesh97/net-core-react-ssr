﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace React_Core_Boilerplate.Models
{
    public class ServiceUser
    {
        public string Login { get; set; }
    }
}
